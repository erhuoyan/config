package testdata

func Foo1() {}
