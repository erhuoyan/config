package testdata

func Foo5() (string, error) { return "", nil }
