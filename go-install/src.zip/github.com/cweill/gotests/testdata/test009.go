package testdata

func (b Bar) Foo9() Bar { return Bar{} }
