package testdata

func (r *Reserved) DontFail() string {
	return ""
}
